package Menu;

import javafx.scene.shape.Rectangle;
//Esta clase es unicamente para la colocacion de los bloques en el escenario de juego
public class Batalla {
 private Rectangle q ;
 private Rectangle w ;
 private Rectangle e ;
 private Rectangle r ; 
 private Rectangle t ;
 private Rectangle y ;
 private Rectangle u ;
 private Rectangle i ;
 
 public Batalla(double a,double b,double c,double d) {
	 this.q= new Rectangle(a,b);
	 this.w= new Rectangle(a,b);
	 this.e= new Rectangle(a,b);
	 this.r= new Rectangle(a,b);
	 this.t= new Rectangle(c,d);
	 this.y= new Rectangle(c,d);
	 this.u= new Rectangle(c,d);
	 this.i= new Rectangle(c,d);
 }
 public Rectangle getBarra1() {
	 return this.q ;
 }
 public Rectangle getBarra2() {
	 return this.w ;
 }
 public Rectangle getBarra3() {
	 return this.e ;
 }
 public Rectangle getBarra4() {
	 return this.r ;
 }
 public Rectangle getBarra5() {
	 return this.t ;
 }
 public Rectangle getBarra6() {
	 return this.y ;
 }
 public Rectangle getBarra7() {
	 return this.u ;
 }
 public Rectangle getBarra8() {
	 return this.i ;
 }
 public void getPosicio() {
	 this.q.relocate(80, 120);
	 this.w.relocate(460, 120);
	 this.e.relocate(80, 370);
	 this.r.relocate(460,370);
	 this.t.relocate(360, 470);
	 this.y.relocate(130, 470);
	 this.u.relocate(360, 70);
	 this.i.relocate(80, 80);
 }
 }

