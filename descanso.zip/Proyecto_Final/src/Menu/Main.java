package Menu;
	
import Tanques.Disparo;
import Tanques.Tanque;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Main extends Application{
	private Tanque tank1;
	private Tanque tank2;
	//private Disparo bala ;
	private Batalla s;
	int disparoX = 0;
	int disparoY = 1;
	private Bounds limite;
	private double salir ;
	private Disparo disp ;
	private Disparo disparo ;
	private Disparo disparo2 ;
	private Disparo disparo3 ;
	private Disparo disparo4 ;
	private double perder;
	private double perder2;
	private double perder3;
	private double perder4;
	private Stage primaryStage;
	
	private Button btnUno;
	private Button btnTres;
	// Primer escenario
	public void start(Stage primaryStage) {
		this.primaryStage=primaryStage;
		//Image img = new Image("application/tanque_fondo.jpg");
		Image img = new Image("Menu/battles_tank.jpg");
		ImageView imgView = new ImageView(img);
		// imgView.

		HBox areaBotones = new HBox();
		btnUno = new Button("Iniciar");
		btnUno.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
            	mostrarPantalla2();
            }
		});
		//Button btnDos = new Button("Seleccionar Mapa");
		btnTres = new Button("Salir");
		areaBotones.getChildren().addAll(btnUno, btnTres);
//		areaBotones.setTranslateY(-1);
//		areaBotones.setTranslateX(126);
		btnUno.setTranslateY(-1);
		//btnDos.setTranslateY(10);
		btnTres.setTranslateY(20);
		btnTres.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
        		System.exit(0);
            }
		});
		// areaBotones.setOnAction(this);

		// BorderPane root = new BorderPane();
		StackPane root = new StackPane();
		// root.setCenter(imgView);
		// root.setBottom(areaBotones);
		root.getChildren().addAll(imgView, areaBotones);
		Scene scene = new Scene(root, 450, 253);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	// C�digo para que el tanque no sobrepase las figuras del escenario
	public boolean chocaPared(double x,double y){
		boolean respuesta = false;
		if(x>310 && x<510 && y>20 && y<120){
			respuesta = true;
		}
		if(x>410 && x<510 && y>70 && y<270){
			respuesta = true;
		}
		if(x>30 && x<230 && y>30 && y<130){
			respuesta = true;
		}
		if(x>30 && x<130 && y>30 && y<270){
			respuesta = true;
		}
		if(x>30 && x<130 && y>320 && y<520){
			respuesta = true;
		}
		if(x>30 && x<280 && y>420 && y<520){
			respuesta = true;
		}
		if(x>310 && x<510 && y>420 && y<520){
			respuesta = true;
		}
		if(x>410 && x<510 && y>320 && y<520){
			respuesta = true;
		}
		
		return respuesta;
	}
	//Segundo escenario
	public void mostrarPantalla2(){
		Stage primaryStage2= new Stage();
		try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root,600,600);
			tank1 = new Tanque(50.0,50.0,scene);
			tank2 = new Tanque(50.0,50.0,scene);
			s = new Batalla(50.0,150.0,150.0,50.0);
			root.getChildren().addAll(tank1.getAdherir(),tank2.getAdherir(),s.getBarra1(),s.getBarra2(),s.getBarra3(),s.getBarra4(),s.getBarra5(),s.getBarra6(),s.getBarra7(),s.getBarra8());
           limite=root.getBoundsInLocal();
         
			tank1.getAdherir();			
			s.getPosicio();
			tank1.setPosicion(300,280);
			tank2.setPosicion(5,5);
			
			// Animacion del cuadrado del medio
			Timeline timeline = new Timeline(new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent t) {
					disparo= new Disparo(10.0,scene,Color.BLACK);
                	root.getChildren().addAll(disparo.getCir());
                	DisparoRunnable disparoRunX= new DisparoRunnable(disparo,tank1.PosicioX(),tank1.PosicionY(),-1,0);
                	Thread thread= new Thread(disparoRunX);
                	thread.start();
                	
                	
                	
                	 disparo2= new Disparo(10.0,scene,Color.BLACK);
                	root.getChildren().addAll(disparo2.getCir());
                	DisparoRunnable disparoRun= new DisparoRunnable(disparo2,tank1.PosicioX(),tank1.PosicionY(),1,0);
                	Thread thread2= new Thread(disparoRun);
                	thread2.start();
                	
                	
                	disparo3= new Disparo(10.0,scene,Color.BLACK);
                	root.getChildren().addAll(disparo3.getCir());
                	DisparoRunnable disparoRunX3= new DisparoRunnable(disparo3,tank1.PosicioX(),tank1.PosicionY(),0,1);
                	Thread thread3= new Thread(disparoRunX3);
                	thread3.start();
                	
                	
                	
                	disparo4= new Disparo(10.0,scene,Color.BLACK);
                	root.getChildren().addAll(disparo4.getCir());
                	DisparoRunnable disparoRun4= new DisparoRunnable(disparo4,tank1.PosicioX(),tank1.PosicionY(),0,-1);
                	Thread thread4= new Thread(disparoRun4);
                	thread4.start();
                	
					
				}
			}));
			timeline.setCycleCount(Timeline.INDEFINITE);
			timeline.play();
			
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage2.setScene(scene);
			primaryStage2.show();
			primaryStage.close();
			
			scene.setOnKeyPressed(t->
		  	  {  
		  		  //Animaci�n del disparo
	                if(t.getCode()==KeyCode.ENTER) {
	                	disp= new Disparo(10.0,scene,Color.RED);
	                	root.getChildren().addAll(disp.getCir());
	                	DisparoRunnable dispR= new DisparoRunnable(disp,tank2.PosicioX(),tank2.PosicionY(),disparoX,disparoY);
	                	Thread th= new Thread(dispR);
	                	th.start();
	                	
	                }
	                
	                
	                switch (t.getCode()) {
	    			
	                //Movimiento del cuadrado
	                case A:
	                	//Movimiento
	    				tank2.getAdherir().setLayoutX(tank2.PosicioX()-5);
	    				System.out.println(tank2.PosicioX()+" "+tank2.PosicionY());
	    				if(chocaPared(tank2.PosicioX(),tank2.PosicionY())){
	    					tank2.getAdherir().setLayoutX(tank2.PosicioX()+5);
	    				}
	    				disparoX=-1;
	    				disparoY=0;
	    				//Bordes de la pantalla
	    				if (tank2.PosicioX() <= (limite.getMinX())) {

	    					 tank2.getAdherir().setLayoutX(tank2.PosicioX()+5);
	    					}
	    				// Para que el jugador gane
	    				salir = Math.sqrt(Math.pow(300- disp.PosicionX(),2)+Math.pow(280-disp.PosicionY(),2 ));
	                	if(salir<=20)
	                	{
	                		System.out.println("saliodsss");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	//C�digo que se ejecuta cuando el jugador pierde
	                	perder = Math.sqrt(Math.pow(tank2.PosicioX()- disparo.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo.PosicionY(),2 ));
	                	if(perder<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	perder2 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo2.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo2.PosicionY(),2 ));
	                	if(perder2<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	perder3 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo3.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo3.PosicionY(),2 ));
	                	if(perder3<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	perder4 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo4.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo4.PosicionY(),2 ));
	                	if(perder4<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	    				break;
	    			
	    			
	    			case D:
	    				//Moviemiento
	    				tank2.getAdherir().setLayoutX(tank2.PosicioX() + 5);
	    				System.out.println(tank2.PosicioX()+" "+tank2.PosicionY());
						if(chocaPared(tank2.PosicioX(),tank2.PosicionY())){
							tank2.getAdherir().setLayoutX(tank2.PosicioX() - 5);
	    				}
						disparoX=1;
	    				disparoY=0;
	    				//Bordes
	    				if (tank2.PosicioX() +45 >= (limite.getMaxX())) {

	   					 tank2.getAdherir().setLayoutX(tank2.PosicioX()-5);
	   					}
	    				//C�digo para ganar y perder
	    				salir = Math.sqrt(Math.pow(300- disp.PosicionX(),2)+Math.pow(280-disp.PosicionY(),2 ));
	                	if(salir<=20)
	                	{
	                		System.out.println("salio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	perder = Math.sqrt(Math.pow(tank2.PosicioX()- disparo.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo.PosicionY(),2 ));
	                	if(perder<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	perder2 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo2.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo2.PosicionY(),2 ));
	                	if(perder2<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	perder3 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo3.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo3.PosicionY(),2 ));
	                	if(perder3<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	perder4 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo4.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo4.PosicionY(),2 ));
	                	if(perder4<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	    				break;
	    			
	    			
	    			case W:
	    				//Movimiento
	    				tank2.getAdherir().setLayoutY(tank2.PosicionY() - 5);
	    				System.out.println(tank2.PosicioX()+" "+tank2.PosicionY());
						if(chocaPared(tank2.PosicioX(),tank2.PosicionY())){
							tank2.getAdherir().setLayoutY(tank2.PosicionY() + 5);
	    				}
						disparoX=0;
	    				disparoY=-1;
	    				//Bordes
	    				if (tank2.PosicionY() <= (limite.getMinY())
	    						) {

	    				tank2.getAdherir().setLayoutY(tank2.PosicionY()+5);

	    				}
	    				//C�digo para saber si el jugador gana o pierde
	    				salir = Math.sqrt(Math.pow(300- disp.PosicionX(),2)+Math.pow(280-disp.PosicionY(),2 ));
	    				perder4 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo4.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo4.PosicionY(),2 ));
	    				perder3 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo3.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo3.PosicionY(),2 ));
	    				perder2 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo2.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo2.PosicionY(),2 ));
	    				perder = Math.sqrt(Math.pow(tank2.PosicioX()- disparo.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo.PosicionY(),2 ));
	                	if(salir<=20)
	                	{
	       					System.out.println("salio");
	                		Platform.exit();
	    					System.exit(0);
	                	}
	                	
	                	if(perder<=50)
	                	{
	       					System.out.println("perdio");
	                		Platform.exit();
	    					System.exit(0);
	                	}
	                
	                	if(perder2<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	
	                	if(perder3<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	
	                	if(perder4<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	    				break;
	    			
	    			
	    			case S:
	    				//Movimiento
	    				tank2.getAdherir().setLayoutY(tank2.PosicionY() + 5);
	    				System.out.println(tank2.PosicioX()+" "+tank2.PosicionY());
	    				if(chocaPared(tank2.PosicioX(),tank2.PosicionY())){
	    					tank2.getAdherir().setLayoutY(tank2.PosicionY() - 5);
	    				}
	    				disparoX=0;
	    				disparoY=1;
	    				//Bordes
	    				if (tank2.PosicionY()+45 >= (limite.getMaxY())) {

	    					tank2.getAdherir().setLayoutY(tank2.PosicionY()-5);

	    					}
	    				//C�digo para saber si se pierde o gana 
	    				perder4 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo4.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo4.PosicionY(),2 ));
	    				salir = Math.sqrt(Math.pow(300- disp.PosicionX(),2)+Math.pow(280-disp.PosicionY(),2 ));
	    				perder3 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo3.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo3.PosicionY(),2 ));
	    				perder2 = Math.sqrt(Math.pow(tank2.PosicioX()- disparo2.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo2.PosicionY(),2 ));
	    				perder = Math.sqrt(Math.pow(tank2.PosicioX()- disparo.PosicionX(),2)+Math.pow(tank2.PosicionY()-disparo.PosicionY(),2 ));
	                	if(salir<=20)
	                	{
	                		System.out.println("salio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	
	                	if(perder<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	
	                	if(perder2<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	
	                	if(perder3<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	                	
	                	if(perder4<=50)
	                	{
	                		System.out.println("perdio");
	       					Platform.exit();
	    					System.exit(0);
	                	}
	    				break;
	    			} 
	               
		  	  });
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
