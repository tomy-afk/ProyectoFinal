package Menu;

import Tanques.Disparo;
//Esta clase usa un m�todo run para que el movimiento del tanque se ejecute en paralelo con
// el de la bala 
public class DisparoRunnable implements Runnable{
	Disparo disparo;
	double a;
	double b;
	int direccionX;
	int direccionY;
	
	public DisparoRunnable(Disparo disparo,double a, double b,int direccionX,int direccionY){
		this.disparo = disparo;
		this.a = a;
		this.b = b;
		this.direccionX = direccionX;
		this.direccionY = direccionY;
	}

	@Override
	public void run() {
		disparo.getDisparo1(a, b,direccionX,direccionY);
		
	}
}
