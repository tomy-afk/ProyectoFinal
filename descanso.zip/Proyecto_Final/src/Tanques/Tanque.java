package Tanques;

import com.sun.prism.paint.Color;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
//Se crea la clase tanque que por motivos de funcionalidad su codigo estar� en el Main
public class Tanque {
	private Rectangle tank;
	private Scene scene;

	public Tanque(double c, double b, Scene scene) {
		this.tank = new Rectangle(c, b);
		this.scene = scene;
	}


	public Rectangle getAdherir() {
		return this.tank;
	}

	public void setPosicion(int x,int y) {
		tank.relocate(x, y);
	}

	public double PosicioX() {
		return tank.getLayoutX();
	}

	public double PosicionY() {
		return tank.getLayoutY();
	}
}
