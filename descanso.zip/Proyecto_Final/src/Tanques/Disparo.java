package Tanques;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;
//Clase disparo que es el movimiento de las balas
public class Disparo {
	private Circle pelota;
	private BorderPane o;
	private Scene scene;
	private Bounds limites;
	public Disparo(double k, Scene scene,Color color) {
		this.pelota = new Circle(k, color);
		this.o = o;
		this.scene = scene;

	}
// El c�digo de movimiento es este
	public void getDisparo1(double a, double b,int direccionX,int direccionY) {
		if(direccionX == 1){
			pelota.relocate(a, b);
		}else{
			pelota.relocate(a+25, b);
		}

		Timeline timeline = new Timeline(new KeyFrame(Duration.millis(20), new EventHandler<ActionEvent>() {
			// para movimiento en x
			double dx = 2;
			// para movimiento en y
			double dy = 3;
			@Override
			public void handle(ActionEvent t) {
				// mover pelota
				if(direccionX==1||direccionX == -1){
					pelota.setLayoutX(pelota.getLayoutX() + (dx*direccionX));
				}
				if(direccionY==1||direccionY == -1){
					pelota.setLayoutY(pelota.getLayoutY() + (dx*direccionY));
				}
				
			}
		}));

		// movimiento tiempo indefinido
		timeline.setCycleCount(Timeline.INDEFINITE);

		// empezar
		timeline.play();

	}

	public Circle getCir() {
		return this.pelota;
	}
	public double PosicionX()
	{
		return this.pelota.getLayoutX();
	}
	public double PosicionY()
	{
		return this.pelota.getLayoutY();
	}
}
